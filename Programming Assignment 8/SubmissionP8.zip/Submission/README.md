# GraphicsTownJS2015
GraphicsTown2015 in JavaScript - basic framework code for CS559 Project 2.

Majority of code is taken from Computer Graphics Team - UW Madison . 
